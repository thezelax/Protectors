#include "CppUnitTest.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace Test
{
	TEST_CLASS(ClientFileTest)
	{
	public:
      TEST_METHOD(testGetPeFileInfo)
		{
			// TODO: Your test code here
		}
	};
}