# OWASP ZSC Documentation
The Latest version of these documents are available **[HERE](https://www.gitbook.com/book/ali-razmjoo/owasp-zsc/details)**.

 * [Read Online](https://ali-razmjoo.gitbooks.io/owasp-zsc/content/)
 * [PDF Version](https://www.gitbook.com/download/pdf/book/ali-razmjoo/owasp-zsc)
 * [ePub Version](https://www.gitbook.com/download/epub/book/ali-razmjoo/owasp-zsc)
 * [Mobi Version](https://www.gitbook.com/download/mobi/book/ali-razmjoo/owasp-zsc)

There are some extra tricks on the blog which is located [HERE](http://zsc.z3r0d4y.com/blog/archives).