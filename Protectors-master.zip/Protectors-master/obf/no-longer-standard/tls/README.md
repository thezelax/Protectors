This is an "obfuscated TLS" library.

Even when it is completed, it is going to be an ABSOLUTELY MINIMAL version, (supporting ONLY TLS1.2, with ONLY ONE cipher, etc. etc.). 

It is currently derived from OpenSSL v1.1.0g. As a result - this project is licensed under "OpenSSL license".

Also, as OpenSSL license prohibits use of "OpenSSL" in the name of the derived projects - this project is named "Obfuscated TLS".
