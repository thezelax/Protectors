#pragma once
#include "stdafx.h"


const char *GetRootDirectory();
const char *GetLogDirectory();
const char *GetTempDirectory();
bool SetupDirectories();


