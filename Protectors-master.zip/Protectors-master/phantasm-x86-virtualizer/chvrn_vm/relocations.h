#pragma once
#include "stdafx.h"

void test_f();