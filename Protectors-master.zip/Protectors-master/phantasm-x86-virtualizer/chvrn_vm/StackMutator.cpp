#include "stdafx.h"
#include "StackMutator.h"

// omitted