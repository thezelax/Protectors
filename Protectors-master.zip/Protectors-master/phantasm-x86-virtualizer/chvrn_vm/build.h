#pragma once
#include "stdafx.h"

//#define STRIPPED_BUILD