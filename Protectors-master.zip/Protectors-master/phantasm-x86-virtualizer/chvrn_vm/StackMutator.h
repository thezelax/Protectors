#pragma once
#include "stdafx.h"
#include "MappedPeFile.h"
#include "Vm.h"

void mutate(MappedPeFile *target, VmFile *vm);