// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>



// TODO: reference additional headers your program requires here


#pragma warning(disable:4244 4996)

#include "beaengine\BeaEngine.h"

#include <Windows.h>
#include <vector>
#include <WinNT.h>
#include <iostream>
#include <sstream>
#include <utility>
#include <initializer_list>
#include <time.h>
#include <map>
#include <string>

#include "build.h"
#include "log.h"

