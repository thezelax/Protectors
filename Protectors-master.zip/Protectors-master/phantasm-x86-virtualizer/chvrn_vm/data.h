#pragma once
#include "stdafx.h"

bool VirtualizeMov(CodeChunk *code, DISASM *disasm);