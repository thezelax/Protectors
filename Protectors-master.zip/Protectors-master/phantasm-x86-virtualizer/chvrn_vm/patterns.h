#pragma once
#include "stdafx.h"

DWORD findBytePattern(BYTE *data, DWORD length, BYTE *pattern, DWORD patternLength);