#pragma once
#include "stdafx.h"
#include "CodeChunk.h"

bool VirtualizePushPopRegister(CodeChunk *code, DISASM *disasm);