XOR_Crypter
===========


This is a simple file crypter. 
1. Reads in file data.

2. "Encrypts" file data using XOR encryption

3. Outputs file with encrypted data

4. When crypted file is run, file data is decrypted in system memory

5. File is then executed from system memory






Downloading and Contributing
=============================
1. Fork the project
